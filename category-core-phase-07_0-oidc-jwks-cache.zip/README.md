# Phase 07_0-oidc-jwks-cache: OIDC + JWKS cache

- Adds OIDC JWT validator contract and implementation shell with JWKS caching planned.
- To be wired with a real JWKS HTTP client and cache adapter.

## Acceptance
- Cold validation < 150 ms with JWKS fetch.
- Automatic JWKS rotation without downtime.
