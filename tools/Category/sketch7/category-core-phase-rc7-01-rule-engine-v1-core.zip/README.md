# Category rc7-01 — rule-engine-v1-core
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

AND/OR groups, include/exclude, attribute/price/stock/meta
