# Category rc7-12 — cache-keys-policy
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

keys for category/collection/facet; selective invalidation
