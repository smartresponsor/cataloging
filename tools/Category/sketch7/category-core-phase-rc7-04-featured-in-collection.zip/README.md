# Category rc7-04 — featured-in-collection
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

collection.featuredProductId + admin validation
