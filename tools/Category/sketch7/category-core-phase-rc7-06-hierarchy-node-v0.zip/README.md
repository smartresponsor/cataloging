# Category rc7-06 — hierarchy-node-v0
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

catalog/hierarchy/node read-model (MySQL) + breadcrumbs
