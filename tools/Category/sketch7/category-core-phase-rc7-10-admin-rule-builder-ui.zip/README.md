# Category rc7-10 — admin-rule-builder-ui
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

editor AND/OR, presets, expensive-rule warning, simulator
