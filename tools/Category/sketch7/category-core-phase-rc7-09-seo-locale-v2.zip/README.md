# Category rc7-09 — seo-locale-v2
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

canonical/alternate/hreflang/noindex per locale
