# Category rc7-14 — observability-pack
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

/metrics, Grafana board, alerts for rebuild lag & errors
