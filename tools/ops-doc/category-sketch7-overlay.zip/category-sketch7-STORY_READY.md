Category / Sketch 7 — StoryReady (CORE only + extracted add-ons)

CORE artifacts:
- category7-core-winners.zip
- category7-core-overlay-final.zip
- category7-core-last-step.zip
- category7-andyjson-core-kit.zip
- category7-core-repo-ready.zip

Extracted add-on overlay kits:
- category7-addons-all-overlay-kit.zip
- category7-addons-docs-overlay-kit.zip
- category7-addons-unclassified-overlay-kit.zip
