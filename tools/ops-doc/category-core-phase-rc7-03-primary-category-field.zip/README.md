# Category rc7-03 — primary-category-field
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

product.primaryCategoryId + projection index
