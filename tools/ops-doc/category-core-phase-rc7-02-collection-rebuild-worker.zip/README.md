# Category rc7-02 — collection-rebuild-worker
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

deterministic rebuild + diff payload, idempotent, DLQ wire
