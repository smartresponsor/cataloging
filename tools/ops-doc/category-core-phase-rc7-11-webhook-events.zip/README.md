# Category rc7-11 — webhook-events
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

category.updated, collection.rule_changed, collection.rebuilt with diff
