# Category rc7-13 — slo-smoke-profiles
Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp

read p95<=250ms, collection p95<=350ms, approxTotal<=5%
