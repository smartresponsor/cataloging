# Phase 03_0-search-synonym-locale-analyzer: Synonyms + locale analyzers

- Adds Postgres table for synonym dictionary.
- Adds normalizer service for locale-aware term expansion.

## Acceptance
- Measured recall improvement on internal corpus by 10–15%.
- Search p95 ≤ 250 ms with synonym expansion enabled.
