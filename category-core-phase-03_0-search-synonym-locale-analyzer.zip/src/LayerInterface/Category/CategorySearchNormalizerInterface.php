<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace LayerInterface\Category;

interface CategorySearchNormalizerInterface
{
    public function normalize(string $locale, string $term): string;
    public function expand(string $locale, string $term): array;
}
