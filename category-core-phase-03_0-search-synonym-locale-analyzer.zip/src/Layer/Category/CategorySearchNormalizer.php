<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace Layer\Category;

use LayerInterface\Category\CategorySearchNormalizerInterface;
use PDO;

final class CategorySearchNormalizer implements CategorySearchNormalizerInterface
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function normalize(string $locale, string $term): string
    {
        return mb_strtolower(trim($term));
    }

    public function expand(string $locale, string $term): array
    {
        $sql = "SELECT alias FROM category_synonym WHERE locale = :locale AND term = :term";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':locale' => $locale, ':term' => $this->normalize($locale, $term)]);
        $alias = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
        return array_unique(array_merge([$term], $alias));
    }
}
