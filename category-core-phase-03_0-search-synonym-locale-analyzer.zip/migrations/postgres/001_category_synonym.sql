CREATE TABLE IF NOT EXISTS category_synonym (
  id BIGSERIAL PRIMARY KEY,
  locale VARCHAR(8) NOT NULL,
  term VARCHAR(128) NOT NULL,
  alias VARCHAR(128) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_category_synonym_locale_term ON category_synonym(locale, term);
