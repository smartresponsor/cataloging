# Phase 01_0-graphql-tree-connection: GraphQL tree connection v1

- Adds GraphQL connection/edge for Category tree.
- Introduces mirror interfaces and an implementation class to wire resolvers.
- Provides MySQL read-model table and Postgres ltree extension enablement.

## Acceptance
- p95 categoryBySlug ≤ 180 ms on depth 3.
- N+1 does not grow with depth (score ≤ 1.2x).

