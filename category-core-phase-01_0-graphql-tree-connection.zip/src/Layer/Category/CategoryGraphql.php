<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace Layer\Category;

use LayerInterface\Category\CategoryGraphqlInterface;
use LayerInterface\Category\CategoryReadRepositoryInterface;
use LayerInterface\Category\CategoryTreeServiceInterface;

final class CategoryGraphql implements CategoryGraphqlInterface
{
    private CategoryReadRepositoryInterface $read;
    private CategoryTreeServiceInterface $tree;

    public function __construct(
        CategoryReadRepositoryInterface $read,
        CategoryTreeServiceInterface $tree
    ) {
        $this->read = $read;
        $this->tree = $tree;
    }

    public function categoryBySlug(string $slug): array
    {
        $node = $this->read->findBySlug($slug);
        if ($node === null) {
            return [];
        }
        return $this->tree->materializeEdge($node);
    }

    public function childConnection(string $parentId, int $first, ?string $after): array
    {
        $list = $this->read->childList($parentId, $first, $after);
        return $this->tree->connection($list, $first, $after);
    }

    public function ancestorConnection(string $id, int $first, ?string $after): array
    {
        $list = $this->read->ancestorList($id, $first, $after);
        return $this->tree->connection($list, $first, $after);
    }
}
