<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace LayerInterface\Category;

interface CategoryGraphqlInterface
{
    public function categoryBySlug(string $slug): array;
    public function childConnection(string $parentId, int $first, ?string $after): array;
    public function ancestorConnection(string $id, int $first, ?string $after): array;
}
