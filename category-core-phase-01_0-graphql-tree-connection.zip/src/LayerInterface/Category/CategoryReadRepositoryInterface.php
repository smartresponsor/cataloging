<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace LayerInterface\Category;

interface CategoryReadRepositoryInterface
{
    public function findBySlug(string $slug): ?array;
    public function childList(string $parentId, int $limit, ?string $after): array;
    public function ancestorList(string $id, int $limit, ?string $after): array;
}
