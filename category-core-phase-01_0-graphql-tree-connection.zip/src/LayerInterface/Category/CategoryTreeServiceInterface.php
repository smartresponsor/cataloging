<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace LayerInterface\Category;

interface CategoryTreeServiceInterface
{
    public function materializeEdge(array $node): array;
    public function connection(array $nodeList, int $limit, ?string $after): array;
}
