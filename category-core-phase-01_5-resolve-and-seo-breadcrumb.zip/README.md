Phase 01_5 — Resolve + SEO breadcrumb.
- Adds CategoryBreadcrumbBuilder and repo methods bySlug/fullSlug.
- Controller's bySlug now returns category + breadcrumb + SEO.
