# Phase 10_0-projection-runner-v2-lag-guard: Projection v2 + lag guard

- Adds projection runner with lag guard contract.
- Backpressure logic will adapt rate to keep lag in defined SLO bounds.

## Acceptance
- Lag steady ≤ 3 s, burst ≤ 15 s.
- Auto downshift on burst load present.
