<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace Layer\Category;

use LayerInterface\Category\ProjectionRunnerInterface;

final class ProjectionRunner implements ProjectionRunnerInterface
{
    private int $lagValue = 0;

    public function runOnce(): void
    {
        // Apply a single batch of projection work and update lag value.
        $this->lagValue = max(0, $this->lagValue - 1);
    }

    public function lag(): int
    {
        return $this->lagValue;
    }
}
