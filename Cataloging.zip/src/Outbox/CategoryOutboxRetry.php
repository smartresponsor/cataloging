<?php

// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Outbox;

use App\OutboxInterface\CategoryOutboxRetryInterface;

/**
 * Provides the category outbox retry implementation.
 */
final class CategoryOutboxRetry implements CategoryOutboxRetryInterface
{
    /** @var list<array{event:array<string, mixed>,attempt:int,runAt:int}> */
    private array $scheduled = [];

    /**
     * @param array<string, mixed> $event   * @throws \DateMalformedStringException
     * @param int                  $attempt
     *
     * @throws \DateMalformedStringException
     */
    public function schedule(array $event, int $attempt): void
    {
        $normalizedAttempt = max(1, $attempt);
        $runAt = $this->nextRunAt(new \DateTimeImmutable('now'), $normalizedAttempt);

        $this->scheduled[] = [
            'event' => $event,
            'attempt' => $normalizedAttempt,
            'runAt' => $runAt->getTimestamp(),
        ];
    }

    /**
     * Handles the next delay seconds workflow.
     */
    public function nextDelaySeconds(int $attempt): int
    {
        $normalizedAttempt = max(1, $attempt);

        return min(900, 2 ** min($normalizedAttempt, 9));
    }

    /**
     * Handles the next run at workflow.
     *
     * @throws \DateMalformedStringException
     */
    public function nextRunAt(\DateTimeImmutable $now, int $attempt): \DateTimeImmutable
    {
        return $now->modify(sprintf('+%d seconds', $this->nextDelaySeconds($attempt)));
    }

    /** @return list<array{event:array<string, mixed>,attempt:int,runAt:int}> */
    public function scheduled(): array
    {
        return $this->scheduled;
    }
}
