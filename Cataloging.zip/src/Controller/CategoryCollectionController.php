<?php

# Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Controller;

use App\Request\CategoryCollectionRequest;
use App\Service\CatalogCollectionService;
use App\Service\CategoryCollectionRuleNormalizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Handles the category collection controller application flow.
 */
final readonly class CategoryCollectionController
{
    /**
     * Initializes the category collection controller service collaborators.
     */
    public function __construct(
        private CatalogCollectionService $service,
        private CategoryCollectionRuleNormalizer $ruleNormalizer,
    ) {
    }

    /**
     * Executes the invokable workflow for this service.
     */
    #[Route('/api/category/collection', name: 'api_category_collection', methods: ['POST'])]
    public function __invoke(Request $request): JsonResponse
    {
        $input = CategoryCollectionRequest::fromJson((string) $request->getContent());
        if (!$input->isValid()) {
            return new JsonResponse(['ok' => false, 'errors' => $input->getErrors()], 400);
        }

        $result = $this->service->build($this->ruleNormalizer->normalize($input->rules));

        return new JsonResponse([
            'ok' => true,
            'items' => $result,
            'data' => $result,
            'total' => count($result),
        ]);
    }
}
