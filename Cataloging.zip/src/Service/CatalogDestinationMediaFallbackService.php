<?php

// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Service;

use App\Event\CategoryDestinationMediaFallbackEvaluated;
use App\EventInterface\CategoryDestinationMediaFallbackEvaluatedInterface;
use App\PolicyInterface\CategoryDestinationMediaFallbackPolicyInterface;
use App\RepositoryInterface\CategoryMediaBindingRepositoryInterface;
use App\RepositoryInterface\CategorySyndicationDestinationRepositoryInterface;
use App\ServiceInterface\CatalogDestinationMediaFallbackServiceInterface;
use App\ValueObject\CategoryDestinationMediaEvaluationRequest;

/**
 * Provides the catalog destination media fallback service application service.
 */
final readonly class CatalogDestinationMediaFallbackService implements CatalogDestinationMediaFallbackServiceInterface
{
    /**
     * Initializes the catalog destination media fallback service service collaborators.
     */
    public function __construct(
        private CategorySyndicationDestinationRepositoryInterface $destinationRepository,
        private CategoryMediaBindingRepositoryInterface $bindingRepository,
        private CategoryDestinationMediaFallbackPolicyInterface $policy,
    ) {
    }

    /**
     * Handles the evaluate workflow.
     */
    public function evaluate(
        CategoryDestinationMediaEvaluationRequest $request,
    ): CategoryDestinationMediaFallbackEvaluatedInterface {
        $destinationId = $request->destinationId();
        $categoryId = $request->categoryId();
        $destination = $this->destinationRepository->find($destinationId);
        if (null === $destination) {
            throw new \InvalidArgumentException('Unknown destination.');
        }

        $settings = $destination->settings();
        $report = $this->policy->buildReport(
            $destinationId,
            $categoryId,
            $settings,
            $this->bindingRepository->bindingsForCategory($categoryId),
        );

        return new CategoryDestinationMediaFallbackEvaluated(
            $destinationId,
            $categoryId,
            trim($settings['channel'] ?? ''),
            trim($settings['locale'] ?? ''),
            $report->publishable(),
            $report->publishableWithFallback(),
            $report->requiredMissing(),
            $report->warnings(),
            $report->checks(),
            $report->exactMatchedBindingIds(),
            $report->fallbackMatchedBindingIds(),
            $request->actorId(),
            $request->reason(),
            new \DateTimeImmutable(),
        );
    }
}
