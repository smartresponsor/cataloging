<?php

// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\EntityInterface;

/**
 * Defines the contract for category link.
 */
interface CategoryLinkInterface
{
    /**
     * Handles the id workflow.
     */
    public function id(): string;

    /**
     * Handles the taxonomy id workflow.
     */
    public function taxonomyId(): string;

    /**
     * Handles the category id workflow.
     */
    public function categoryId(): string;

    /**
     * Handles the target domain workflow.
     */
    public function targetDomain(): string;

    /**
     * Handles the target class workflow.
     */
    public function targetClass(): string;

    /**
     * Handles the target id workflow.
     */
    public function targetId(): string;

    /**
     * Creates the d at result for the current workflow.
     */
    public function createdAt(): \DateTimeImmutable;
}
