<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\RepositoryInterface\Category;

interface CategoryRepositoryInterface
{
    public function tree(string $taxonomyCode, ?string $parentId, int $depth, string $locale): array;
    public function breadcrumb(string $categoryId, string $locale): array;
    public function slugExists(string $slug, string $taxonomyId, ?string $parentId, string $locale): bool;

    /** @return array{id:string,taxonomyId:string,parentId:?string,name:array,slug:array,meta:array,path:string,order:int} */
    public function create(string $taxonomyId, ?string $parentId, array $name, array $slug, array $meta): array;

    /** @return array{id:string,parentId:?string,order:int} */
    public function move(string $actorId, string $categoryId, ?string $newParentId, int $newOrder): array;

    public function attach(string $actorId, string $categoryId, string $targetDomain, string $targetClass, string $targetId): void;
    public function detach(string $actorId, string $categoryId, string $targetDomain, string $targetClass, string $targetId): void;

    /** @return list<array{id:string,name:string,slug:string}> */
    public function resolve(string $taxonomyCode, string $targetDomain, string $targetId, string $locale): array;
}
