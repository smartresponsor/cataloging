Phase 01_2 — Service operations wired to repository+policy+slugger with domain events.
- Methods now accept actorId for RBAC checks.
- Repository contract expanded with write ops.
