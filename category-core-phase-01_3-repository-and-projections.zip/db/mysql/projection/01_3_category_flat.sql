
-- MySQL read model for category_flat (denormalized view for UI)
create table if not exists category_flat (
  id varchar(26) primary key,
  taxonomy_code varchar(64) not null,
  parent_id varchar(26),
  level int not null,
  full_slug varchar(512) not null,
  full_name varchar(512) not null,
  breadcrumb json not null,
  order_num int not null,
  updated_at timestamp not null default current_timestamp on update current_timestamp
);
create index idx_category_flat_tax_parent on category_flat(taxonomy_code, parent_id, order_num);
