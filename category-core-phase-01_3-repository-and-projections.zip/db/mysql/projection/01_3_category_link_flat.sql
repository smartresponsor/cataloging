
-- MySQL read model for category_link_flat
create table if not exists category_link_flat (
  id varchar(26) primary key,
  taxonomy_code varchar(64) not null,
  category_id varchar(26) not null,
  target_domain varchar(48) not null,
  target_id varchar(26) not null,
  updated_at timestamp not null default current_timestamp on update current_timestamp,
  unique key uq_link (taxonomy_code, category_id, target_domain, target_id)
);
