Phase 01_3 — Repository scaffold and MySQL projections.
- Provides read-model tables: category_flat, category_link_flat.
- Repository implementation class added; infra injects SQL later.
