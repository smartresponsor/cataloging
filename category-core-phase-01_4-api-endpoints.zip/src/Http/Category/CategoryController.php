<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Http\Category;

use App\HttpInterface\Category\CategoryControllerInterface;
use App\ServiceInterface\Category\CategoryInterface as CategoryService;
use App\RepositoryInterface\Category\CategoryRepositoryInterface;

/**
 * Minimal, framework-agnostic controller.
 * Actual framework adapters (Symfony, Slim) map HTTP to these methods.
 */
final class CategoryController implements CategoryControllerInterface
{
    private CategoryService $service;
    private CategoryRepositoryInterface $repo;

    public function __construct(CategoryService $service, CategoryRepositoryInterface $repo)
    {
        $this->service = $service;
        $this->repo = $repo;
    }

    public function tree(array $query, array $route): array
    {
        $taxonomy = (string)$route['taxonomy'];
        $locale = (string)($query['locale'] ?? 'en');
        $depth = (int)($query['depth'] ?? 2);
        $parentId = $query['parentId'] ?? null;
        return $this->repo->tree($taxonomy, $parentId, $depth, $locale);
    }

    public function bySlug(array $query, array $route): array
    {
        $taxonomy = (string)$route['taxonomy'];
        $slug = (string)$route['slug'];
        $locale = (string)($query['locale'] ?? 'en');
        // In 01_5 we'll add repository method bySlug; for now route via resolve+tree if needed.
        return ['taxonomy' => $taxonomy, 'slug' => $slug, 'locale' => $locale];
    }

    public function create(array $body, array $route, array $auth): array
    {
        $actorId = (string)$auth['actorId'];
        $taxonomyId = (string)$body['taxonomyId'];
        $parentId = $body['parentId'] ?? null;
        $name = (array)($body['name'] ?? []);
        $slug = (array)($body['slug'] ?? []);
        $meta = (array)($body['meta'] ?? []);
        return $this->service->create($actorId, $taxonomyId, $parentId, $name, $slug, $meta);
    }

    public function move(array $body, array $route, array $auth): array
    {
        $actorId = (string)$auth['actorId'];
        $categoryId = (string)$route['id'];
        $parentId = $body['parentId'] ?? null;
        $order = (int)($body['order'] ?? 0);
        return $this->service->move($actorId, $categoryId, $parentId, $order);
    }

    public function attach(array $body, array $route, array $auth): void
    {
        $actorId = (string)$auth['actorId'];
        $categoryId = (string)$route['id'];
        $this->service->attach($actorId, $categoryId, (string)$body['targetDomain'], (string)$body['targetClass'], (string)$body['targetId']);
    }

    public function detach(array $body, array $route, array $auth): void
    {
        $actorId = (string)$auth['actorId'];
        $categoryId = (string)$route['id'];
        $this->service->detach($actorId, $categoryId, (string)$body['targetDomain'], (string)$body['targetClass'], (string)$body['targetId']);
    }
}
