Phase 01_4 — HTTP API endpoints and OpenAPI spec.
- Controller interface + implementation (framework-agnostic).
- OpenAPI 3.0 draft for tree/by-slug/create/move/attach/detach.
