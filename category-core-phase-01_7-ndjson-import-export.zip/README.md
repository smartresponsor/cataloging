Phase 01_7 — NDJSON import/export with dry-run, validation, report.
