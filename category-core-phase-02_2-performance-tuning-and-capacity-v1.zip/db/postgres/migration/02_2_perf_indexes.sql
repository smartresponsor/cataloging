
-- Narrow composite indexes to match frequent patterns
create index if not exists idx_category_tax_parent_order_created on category(taxonomy_id, parent_id, "order", created_at);
-- Example partial index for roots only
create index if not exists idx_category_roots on category("order") where parent_id is null;
