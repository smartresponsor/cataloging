
# Category SLO (v1)
- GET /category/{taxonomy}/tree: p95 ≤ 120ms @ 500 rps
- GET /category/{taxonomy}/by-slug/{slug}: p95 ≤ 80ms @ 500 rps
- POST /category/{taxonomy} (create): p95 ≤ 150ms @ 100 rps
- Projection lag: ≤ 5s p95 under peak write load
