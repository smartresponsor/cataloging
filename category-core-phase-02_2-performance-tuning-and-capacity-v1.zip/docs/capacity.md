
# Capacity v1
- Postgres: ltree-enabled, shared_buffers 25% RAM, effective_cache_size 50% RAM.
- MySQL read schema: category_flat and category_link_flat sized for 10M rows.
- Cache: Redis for tree slices/breadcrumb, TTL 60s, event-driven invalidation.
- Rollout: canary 5% traffic, scale horizontally on repo read-side.
