Phase 02_2 — Performance Tuning & Capacity v1 (indexes, cache contracts, SLO/capacity docs).
