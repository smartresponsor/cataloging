Phase 02_0 — Idempotency keys and outbox retry contracts (Redis/Queue in infra).
