<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Outbox\Category;

use App\OutboxInterface\Category\CategoryOutboxRetryInterface;

final class CategoryOutboxRetry implements CategoryOutboxRetryInterface
{
    public function schedule(array $event, int $attempt): void
    {
        // Infra layer enqueues with backoff: 1, 2, 4, 8, 16... seconds (cap).
    }
}
