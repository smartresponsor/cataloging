# Phase 05_0-rule-based-collection-v1: Rule-based collection v1

- Adds storage for rule DSL and a service contract to evaluate it.
- The service returns a virtual category selection (IDs list).

## Acceptance
- Evaluation ≤ 400 ms on mock 100k SKU dataset.
- Cache invalidation triggered by ProductChange, PriceChange, StockChange events.
