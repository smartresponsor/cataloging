
-- JSONB GIN indexes to speed up localized slug lookups (application enforces uniqueness)
create index if not exists idx_category_slug_gin on category using gin (slug jsonb_path_ops);
create index if not exists idx_category_name_gin on category using gin (name jsonb_path_ops);
