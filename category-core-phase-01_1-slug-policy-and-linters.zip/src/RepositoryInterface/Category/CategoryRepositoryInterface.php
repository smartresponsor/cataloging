<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\RepositoryInterface\Category;

interface CategoryRepositoryInterface
{
    public function tree(string $taxonomyCode, ?string $parentId, int $depth, string $locale): array;
    public function breadcrumb(string $categoryId, string $locale): array;

    /** Check if a slug already exists within given taxonomy+parent for locale. */
    public function slugExists(string $slug, string $taxonomyId, ?string $parentId, string $locale): bool;
}
