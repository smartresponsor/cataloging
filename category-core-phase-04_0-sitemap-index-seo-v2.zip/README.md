# Phase 04_0-sitemap-index-seo-v2: Sitemap index + SEO v2

- Adds URL history to keep permanent links list for SEO.
- Adds sitemap index generator skeleton (stream-oriented).

## Acceptance
- Index generation < 60 s for 100k nodes on stage.
- Smoke crawler: 0 broken links.
