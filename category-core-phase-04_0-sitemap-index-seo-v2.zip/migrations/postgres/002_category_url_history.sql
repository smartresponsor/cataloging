CREATE TABLE IF NOT EXISTS category_url_history (
  id BIGSERIAL PRIMARY KEY,
  category_id UUID NOT NULL,
  slug VARCHAR(191) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (category_id, slug)
);
