# Phase 08_0-edge-purge-client-breaker: Edge purge + breaker

- Adds Edge purge clients (Fastly/Cloudflare) behind a tiny abstraction.
- Adds a simple circuit breaker to protect from provider degradation.

## Acceptance
- 99% purge latency < 2 s on stage.
- When provider fails, breaker opens and shedding is applied.
