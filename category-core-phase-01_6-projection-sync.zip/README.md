Phase 01_6 — Projection sync (outbox → MySQL read models).
- CategoryProjectionSync worker + interface.
- SQL helper skeletons for upsert operations.
