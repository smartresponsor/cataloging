
-- Helper procedures (to be adapted to your MySQL flavor):
-- upsert_category_flat(id, taxonomy_code, parent_id, level, full_slug, full_name, breadcrumb_json, order_num)
-- upsert_category_link_flat(id, taxonomy_code, category_id, target_domain, target_id)
