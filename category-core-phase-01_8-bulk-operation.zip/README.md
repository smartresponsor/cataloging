Phase 01_8 — Bulk operations with idempotent batch key and guarded execution.
