
# Projection metrics
- projection_lag_seconds (gauge)
- projection_events_processed_total (counter)
- projection_backoff_seconds (histogram)
- projection_errors_total (counter)
