Phase 02_1 — Projection Runner with backoff + metrics doc.
