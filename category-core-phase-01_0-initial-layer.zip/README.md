# Category Component — Phase 01_0 (initial layer)

Canon:
- Singular naming; domain prefix in class names.
- Mirror folders: <Layer> ↔ <Layer Interface>.
- Postgres = Data; MySql = Infrastructure (projections in later phases).
- EN-only comments; header present in each PHP file.

This phase contains entities, interfaces, basic service contract, repository/policy contracts,
exceptions, events, and initial Postgres migrations (with ltree).
