-- Postgres migrations for Category (phase 01_0)
create extension if not exists ltree;

create table if not exists taxonomy (
  id         varchar(26) primary key,
  code       varchar(64) unique not null,
  name       jsonb not null,
  rule       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists category (
  id           varchar(26) primary key,
  taxonomy_id  varchar(26) not null references taxonomy(id),
  parent_id    varchar(26) references category(id),
  name         jsonb not null,
  slug         jsonb not null,
  path         ltree not null,
  "order"      int not null default 0,
  meta         jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists idx_category_path on category using gist(path);
create index if not exists idx_category_tax_parent_order on category(taxonomy_id, parent_id, "order");

create table if not exists category_link (
  id            varchar(26) primary key,
  taxonomy_id   varchar(26) not null references taxonomy(id),
  category_id   varchar(26) not null references category(id),
  target_domain varchar(48) not null,
  target_class  varchar(128) not null,
  target_id     varchar(26) not null,
  created_at    timestamptz not null default now(),
  unique(taxonomy_id, category_id, target_domain, target_id)
);
