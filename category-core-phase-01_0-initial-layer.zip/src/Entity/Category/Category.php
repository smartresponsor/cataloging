<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Entity\Category;

/**
 * Category root entity.
 * Rules:
 * - ULID as id
 * - i18n fields for name/slug as JSON (per-locale)
 * - Materialized path via ltree kept in Store/DB
 */
final class Category
{
    /** @var string ULID */
    private string $id;
    private string $taxonomyId; // ULID
    private ?string $parentId;  // ULID or null
    /** @var array<string,string> */
    private array $name;
    /** @var array<string,string> */
    private array $slug;
    private string $path; // ltree
    private int $order;
    /** @var array<string,mixed> */
    private array $meta;
    private \DateTimeImmutable $createdAt;
    private \DateTimeImmutable $updatedAt;

    public function __construct(
        string $id,
        string $taxonomyId,
        ?string $parentId,
        array $name,
        array $slug,
        string $path,
        int $order,
        array $meta,
        \DateTimeImmutable $createdAt,
        \DateTimeImmutable $updatedAt
    ) {
        $this->id = $id;
        $this->taxonomyId = $taxonomyId;
        $this->parentId = $parentId;
        $this->name = $name;
        $this->slug = $slug;
        $this->path = $path;
        $this->order = $order;
        $this->meta = $meta;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
    }

    public function id(): string { return $this->id; }
    public function taxonomyId(): string { return $this->taxonomyId; }
    public function parentId(): ?string { return $this->parentId; }
    /** @return array<string,string> */
    public function name(): array { return $this->name; }
    /** @return array<string,string> */
    public function slug(): array { return $this->slug; }
    public function path(): string { return $this->path; }
    public function order(): int { return $this->order; }
    /** @return array<string,mixed> */
    public function meta(): array { return $this->meta; }
    public function createdAt(): \DateTimeImmutable { return $this->createdAt; }
    public function updatedAt(): \DateTimeImmutable { return $this->updatedAt; }
}
