<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\PolicyInterface\Category;

interface CategoryPolicyInterface
{
    public function canEdit(string $actorId, string $taxonomyId, ?string $categoryId): bool;
    public function validateSlug(array $slug, string $taxonomyId, ?string $parentId): void;
}
