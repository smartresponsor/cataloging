<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Repository\Category;

use App\RepositoryInterface\Category\CategoryRepositoryInterface;

/** SQL-backed repository (implementation details filled in next phases). */
final class CategoryRepository implements CategoryRepositoryInterface
{
    public function tree(string $taxonomyCode, ?string $parentId, int $depth, string $locale): array
    {
        return [];
    }

    public function breadcrumb(string $categoryId, string $locale): array
    {
        return [];
    }
}
