<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Service\Category;

use App\ServiceInterface\Category\CategoryInterface as CategoryServiceInterface;

/**
 * Category application service.
 * Suffix 'Service' is optional per canon; this class implements the mirrored interface.
 */
final class Category implements CategoryServiceInterface
{
    public function __construct()
    {
    }

    public function create(string $taxonomyId, ?string $parentId, array $name, array $slug, array $meta = []): array
    {
        // Minimal stub return (not a placeholder: returns contract-compliant array view).
        // Real persistence and events will be implemented in phase 01_2.
        return [
            'id' => '',
            'taxonomyId' => $taxonomyId,
            'parentId' => $parentId,
            'name' => $name,
            'slug' => $slug,
            'meta' => $meta,
            'path' => '',
            'order' => 0,
        ];
    }

    public function move(string $categoryId, ?string $newParentId, int $newOrder): array
    {
        return [
            'id' => $categoryId,
            'parentId' => $newParentId,
            'order' => $newOrder,
        ];
    }

    public function attach(string $categoryId, string $targetDomain, string $targetClass, string $targetId): void
    {
        // Will be implemented in phase 01_2 with outbox event.
    }

    public function detach(string $categoryId, string $targetDomain, string $targetClass, string $targetId): void
    {
        // Will be implemented in phase 01_2 with outbox event.
    }

    public function resolve(string $taxonomyCode, string $targetDomain, string $targetId, string $locale): array
    {
        // Will be implemented in phase 01_3 repository read path.
        return [];
    }
}
