<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\Policy\Category;

use App\PolicyInterface\Category\CategoryPolicyInterface;

/** Basic policy stub; real rules to be added in subsequent phases. */
final class CategoryPolicy implements CategoryPolicyInterface
{
    public function canEdit(string $actorId, string $taxonomyId, ?string $categoryId): bool
    {
        return true;
    }

    public function validateSlug(array $slug, string $taxonomyId, ?string $parentId): void
    {
        // Validate in 01_1 (i18n per-locale uniqueness).
    }
}
