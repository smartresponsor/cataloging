<?php
// Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
declare(strict_types=1);

namespace App\RepositoryInterface\Category;

interface CategoryRepositoryInterface
{
    public function tree(string $taxonomyCode, ?string $parentId, int $depth, string $locale): array;
    public function breadcrumb(string $categoryId, string $locale): array;
}
