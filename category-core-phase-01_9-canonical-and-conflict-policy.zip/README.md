Phase 01_9 — Canonical locale (en) and SEO redirects on slug change; adds redirect table.
