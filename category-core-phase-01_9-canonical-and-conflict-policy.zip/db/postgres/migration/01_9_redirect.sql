
create table if not exists category_redirect (
  id varchar(26) primary key,
  frm varchar(1024) not null,
  dst varchar(1024) not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_category_redirect_frm on category_redirect(frm);
