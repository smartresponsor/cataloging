# Phase 02_0-rest-etag-selective-field: REST ETag + selective fields

- Adds HTTP cache helper with stable ETag.
- Adds selective field serializer to shrink payloads.

## Query Parameters
- `fields=a,b,c` to include only certain fields.
- `exclude=x,y` to remove fields from the response.

## Acceptance
- List endpoints cache-hit ≥ 85%.
- Outbound traffic on listings reduced by ≥ 40%.
