#!/usr/bin/env bash
# Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
# Author: Oleksandr Tishchenko <dev@smartresponsor.com>
set -euo pipefail
echo "[category] import requeue: dlq limit=${1:-500}"

