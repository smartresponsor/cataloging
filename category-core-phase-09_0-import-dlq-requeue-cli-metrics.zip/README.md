# Phase 09_0-import-dlq-requeue-cli-metrics: Import DLQ requeue + metrics

- Adds simple CLI wrappers for import run and DLQ requeue (to be wired to console commands).
- Expose throughput, error-rate, and DLQ size via /metrics in the main app.

## Acceptance
- Stable import ≥ 2k nodes/min on stage.
- Error budget ≤ 0.3%.
