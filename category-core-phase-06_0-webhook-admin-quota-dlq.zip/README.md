# Phase 06_0-webhook-admin-quota-dlq: Webhook admin + quota + DLQ

- Adds webhook tables and admin service to manage keys, deliveries, and DLQ.
- Provides requeue operation intended to be exposed via CLI/UI.

## Acceptance
- Delivery success p99 ≥ 99.5% on stage.
- Requeue in ≤ 2 clicks (UI) or one CLI call.
