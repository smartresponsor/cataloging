#!/usr/bin/env bash
echo '[SMOKE] 03_2 — product-order-hint'
