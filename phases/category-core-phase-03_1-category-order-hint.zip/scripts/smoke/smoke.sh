#!/usr/bin/env bash
echo '[SMOKE] 03_1 — category-order-hint'
