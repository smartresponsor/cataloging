# Category RC4 — Phase 03_1: category-order-hint
