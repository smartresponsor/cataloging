<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategoryOrderHint { public function normalize(?float $v): ?float { if($v===null){return null;} return max(0.0,min(1.0,$v)); } }
