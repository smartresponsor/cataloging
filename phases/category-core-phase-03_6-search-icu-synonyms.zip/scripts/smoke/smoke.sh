#!/usr/bin/env bash
echo '[SMOKE] 03_6 — search-icu-synonyms'
