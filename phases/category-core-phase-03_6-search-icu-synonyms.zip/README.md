# Category RC4 — Phase 03_6: search-icu-synonyms
