<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategorySearchIndexer { public function analyzer(): string { return 'category_text_icu'; } }
