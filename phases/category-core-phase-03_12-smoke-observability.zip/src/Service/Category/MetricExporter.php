<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; interface CategoryMetricInterface{ public function gauge(): array; public function counter(): array; public function histogram(): array; } final class MetricExporter{ private CategoryMetricInterface $metric; public function __construct(CategoryMetricInterface $m){$this->metric=$m;} public function render(): string { $line=[]; foreach($this->metric->counter() as $k=>$v){$line[]=$k.' '.$v;} foreach($this->metric->gauge() as $k=>$v){$line[]=$k.' '.$v;} return implode("\n",$line)."\n"; }}