#!/usr/bin/env bash
echo '[SMOKE] 03_12 — smoke-observability'
