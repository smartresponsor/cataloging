#!/usr/bin/env bash
echo '[SMOKE] 03_9 — perf-tuning'
