<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; final class CategoryCacheKey{ public function nav(string $l,?string $t,?string $p): string {return 'category:nav:'.$l.':'.($t??'root').':'.($p??'root');}}