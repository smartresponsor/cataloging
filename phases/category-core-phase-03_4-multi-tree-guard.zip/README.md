# Category RC4 — Phase 03_4: multi-tree-guard
