#!/usr/bin/env bash
echo '[SMOKE] 03_4 — multi-tree-guard'
