<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategoryTreeRegistry { private array $tree=[]; public function register(string $id,string $label): void { $this->tree[$id]=$label; } public function has(string $id): bool { return array_key_exists($id,$this->tree);} }
