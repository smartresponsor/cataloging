<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategoryAcl { public function can(string $role,string $op): bool { if($role==='category.owner'){return true;} if($role==='category.editor'){ return in_array($op,['read','write','move'],true);} return $op==='read'; } }
