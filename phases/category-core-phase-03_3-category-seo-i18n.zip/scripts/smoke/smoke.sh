#!/usr/bin/env bash
echo '[SMOKE] 03_3 — category-seo-i18n'
