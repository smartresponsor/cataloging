<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategorySeoPolicy {
    public function title(string $s): string { $s=strip_tags($s); if(mb_strlen($s)>60){$s=mb_substr($s,0,60);} return trim(preg_replace('/\s+/u',' ',$s) ?? $s); }
    public function description(string $s): string { $s=strip_tags($s); if(mb_strlen($s)>160){$s=mb_substr($s,0,160);} return trim(preg_replace('/\s+/u',' ',$s) ?? $s); }
}
