#!/usr/bin/env bash
echo '[SMOKE] 03_8 — graphql-connections'
