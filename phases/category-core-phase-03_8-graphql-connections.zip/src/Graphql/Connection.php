<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Graphql; final class Connection{private array $edge; private PageInfo $pageInfo; public function __construct(array $e, PageInfo $p){$this->edge=$e;$this->pageInfo=$p;} }