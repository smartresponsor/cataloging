<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Graphql; final class PageInfo{private ?string $startCursor; private ?string $endCursor; private bool $hasPrevious; private bool $hasNext; public function __construct(?string $s,?string $e,bool $p,bool $n){$this->startCursor=$s;$this->endCursor=$e;$this->hasPrevious=$p;$this->hasNext=$n;} }