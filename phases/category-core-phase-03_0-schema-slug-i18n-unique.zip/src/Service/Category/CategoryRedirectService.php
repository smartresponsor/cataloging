<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategoryRedirectService {
    public function record(string $categoryId, string $locale, string $legacySlug): array {
        return ['categoryId'=>$categoryId,'locale'=>$locale,'legacySlug'=>$legacySlug];
    }
}
