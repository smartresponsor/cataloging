<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CategorySlugPolicy {
    public function normalize(string $s): string {
        $s = iconv('UTF-8','ASCII//TRANSLIT',$s);
        if ($s===false) { $s='n'; }
        $s = strtolower(preg_replace('~[^a-z0-9]+~','-',$s) ?? '');
        $s = trim(preg_replace('~-+~','-',$s) ?? '', '-');
        return $s ?: 'n';
    }
}
