CREATE TABLE IF NOT EXISTS category_entity(id TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS category_locale(category_id TEXT, locale TEXT, slug TEXT);
CREATE TABLE IF NOT EXISTS category_redirect(category_id TEXT, locale TEXT, legacy_slug TEXT);