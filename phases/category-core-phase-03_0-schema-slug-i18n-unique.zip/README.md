# Category RC4 — Phase 03_0: schema-slug-i18n-unique
