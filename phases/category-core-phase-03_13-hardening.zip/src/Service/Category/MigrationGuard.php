<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; interface MigrationGuardInterface{ public function plan(array $m): array; } final class MigrationGuard implements MigrationGuardInterface{ public function plan(array $m): array { $a=[]; foreach($m as $f){ $a[]=['file'=>$f,'checksum'=>sha1($f)]; } return ['apply'=>$a,'rollback'=>array_reverse($a)]; }}