#!/usr/bin/env bash
echo '[SMOKE] 03_13 — hardening'
