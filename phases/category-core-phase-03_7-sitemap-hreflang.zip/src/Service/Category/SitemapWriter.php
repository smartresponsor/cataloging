<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class SitemapWriter {
    public function write(array $base, array $row): string {
        $xml = new \DOMDocument('1.0','UTF-8');
        $urlset = $xml->createElement('urlset');
        $urlset->setAttribute('xmlns','http://www.sitemaps.org/schemas/sitemap/0.9');
        $urlset->setAttribute('xmlns:xhtml','http://www.w3.org/1999/xhtml');
        $xml->appendChild($urlset);
        $group=[]; foreach($row as $r){ $group[$r['slug']][]=$r; }
        foreach($group as $slug=>$alt){ $url=$xml->createElement('url'); foreach($alt as $a){ $loc=rtrim($base[$a['locale']]??'','/').'/'.$slug; if($url->getElementsByTagName('loc')->length===0){ $url->appendChild($xml->createElement('loc',htmlspecialchars($loc,ENT_XML1))); } $link=$xml->createElement('xhtml:link'); $link->setAttribute('rel','alternate'); $link->setAttribute('hreflang',$a['locale']); $link->setAttribute('href',$loc); $url->appendChild($link);} $urlset->appendChild($url);} return (string)$xml->saveXML(); }
}
