#!/usr/bin/env bash
echo '[SMOKE] 03_7 — sitemap-hreflang'
