<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);

namespace SmartResponsor\Category\Service\Category;
final class CollectionRuleEngine {
    public function match(array $rule, array $product): bool {
        $type = $rule['type'] ?? ''; $mode = $rule['mode'] ?? 'include'; $ok=false;
        if($type==='attr_eq'){ $ok = isset($product[$rule['key']??'']) && $product[$rule['key']] === ($rule['value']??null); }
        if($type==='price_range'){ $p=(float)($product['price']??0); $min=$rule['min']??null; $max=$rule['max']??null; $ok = ($min is null || $p>= (float)$min) && ($max is null || $p<= (float)$max); }
        return $mode==='include' && $ok || $mode==='exclude' && not $ok;
    }
}
