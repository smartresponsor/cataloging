#!/usr/bin/env bash
echo '[SMOKE] 03_5 — collection-rule-engine'
