#!/usr/bin/env bash
echo '[SMOKE] 03_10 — webhooks-quota-admin'
