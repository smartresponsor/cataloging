<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; final class WebhookPolicy{ public function signature(string $secret,string $body,string $nonce): string{ return base64_encode(hash_hmac('sha256',$body.$nonce,$secret,true)); }}