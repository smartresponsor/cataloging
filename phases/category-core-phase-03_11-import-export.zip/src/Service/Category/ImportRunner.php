<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; final class ImportRunner{ public function run(array $line): array { $c=[]; foreach($line as $raw){ $row=json_decode($raw,true); if(!is_array($row)){continue;} $t=$row['type']??'unknown'; $c[$t]=($c[$t]??0)+1; } return $c; }}