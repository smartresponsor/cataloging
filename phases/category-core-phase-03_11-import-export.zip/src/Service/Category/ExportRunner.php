<?php
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * Author: Oleksandr Tishchenko <dev@smartresponsor.com>
 */
declare(strict_types=1);
namespace SmartResponsor\Category\Service\Category; final class ExportRunner{ public function run(array $s): array { $o=[]; foreach($s as $t=>$rows){ foreach($rows as $r){ $o[]=json_encode(['type'=>$t]+$r); } } return $o; }}