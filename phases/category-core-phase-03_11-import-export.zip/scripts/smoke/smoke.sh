#!/usr/bin/env bash
echo '[SMOKE] 03_11 — import-export'
